### 1.5.0 - 2014-06-15
* MKL: Built with Intel MKL 11.1 Update 3

### 1.4.0 - 2014-03-01
* MKL: Built with Intel MKL 11.1 Update 2
* MKL: Capability querying support
