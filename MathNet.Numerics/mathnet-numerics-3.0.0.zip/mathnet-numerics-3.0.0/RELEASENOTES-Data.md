### 3.0.0-beta02 - 2014-06-15
* Matlab: MATLAB Reader now static and stateless; easier to use
* Text: MatrixMarket: Compression enum instead of boolean flag
* Require Math.NET Numerics v3.0.0-beta03 (fixes build-version issue)

### 3.0.0-beta01 - 2014-04-23
* First v3 beta release
