using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NUnitTests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NUnitTests")]
[assembly: AssemblyCopyright("Copyright �  2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: ComVisible(false)]
[assembly: Guid("bb41bee6-eb4c-48c9-8edd-7a5ae2422567")]

[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]
[assembly: AssemblyInformationalVersion("3.0.0-beta02")]
