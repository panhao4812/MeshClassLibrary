param($rootPath, $toolsPath, $package, $project)

Add-BindingRedirect $project.Name