#pragma once

#include "mkl_dss.h"
#include "mkl_types.h"

#define dss_int             MKL_INT
#define dss_complex_float   MKL_Complex8
#define dss_complex_double  MKL_Complex16

